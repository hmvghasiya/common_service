@if($loan_id ==1)
<div class="form-group col-md-12">
                                    <label>Signature  Photo</label>
                                    <input type="file" name="signature" class="form-control" value="" placeholder="Enter Value">
                                </div>
@else

<div class="form-group col-md-12">
                                    <label>ITR 3 year  Photo</label>
                                    <input type="file" name="itr_3_year" class="form-control" value="" placeholder="Enter Value">
                                </div>
@endif