<?php if(isset($data)): ?>
<p>Address : <?php echo e($data->address); ?></p>
<p>City : <?php echo e($data->city); ?></p>
<p>State : <?php echo e($data->state); ?></p>
<?php endif; ?><?php /**PATH E:\laragon\www\open_aisa\resources\views/ration_card/partial/address.blade.php ENDPATH**/ ?>