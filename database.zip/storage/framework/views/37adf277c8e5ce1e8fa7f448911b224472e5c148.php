<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="content-type" content="" /><!-- /Added by HTTrack -->
<head><title>
    Member Login || Recharge, Bill Payment, Money Transfer, Aeps, Bbps, Pan, Travel, And ,API Provider
</title><meta charset="utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="description" content="Recharge Portal B2B. Development and support by Noble Web Studio" />
<meta name="author" content="Noble Web Studio Pvt. Ltd." />
<link href="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/logincss/bootstrap.min.css" rel="stylesheet" type="text/css" />
<!-- Font Awesome -->
    <link  href="<?php echo e(asset('')); ?>assets/nikatby.in/cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" />
    <!-- Ionicons -->
    <link  href="<?php echo e(asset('')); ?>assets/nikatby.in/cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.html" />

    <!-- <link href="Portal/logincss/font-awesome.min.css" rel="stylesheet" type="text/css" /> -->
    <link href="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/logincss/custom2.css" rel="stylesheet" type="text/css" />
    <style>
    .annoucement {width: 84%;}
    .gry_bx {background: #fffffe;border: #fff 1px solid;}
    </style>
 <script type="text/javascript">
        function myvldt(a) {
            document.getElementById("txtravi").value = "1";
        }
    </script>
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>assets/cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
</head>
<body id="mybody" style="background-image: url(<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/images/1.jpg);">
    
        
<div>

<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="DPCZeqzlKywZvktLQjLWDHDUcylMLmFH+ZFrLQNLDGlvMpDPLcWcp/XEF89692BMwCtipJ76Qzi9vuPYvWpMTtmxUXgF96xHxMOm8owldH0Q76QadiiqD8T0/KHqFBctnKxK41NeNY2FP6zR9WtI5QEwSwrUtjgAJ2otKJsx1teGgDo0u8A6sxkeTwJF2XZigL3KZqRFSE/OFJoioIHXBNza5X7lm3k4CBSVA6wzJKJXIHpdnsivhIv5Q6KLo2wrA1kskbf04E6VVx3AWUBPLxd5rfLE/D4xQwBBK19cpgR3VmiBbrbPBE6lTk5tDwepQmhwsiTIIaZP7zMWsWB0xAZKvUni590TRAba4ExQc0ukdL659luXnBG4jNI6pZ7rYIGa5dFk7tFfOd8EQZ87hXt+XffC/03d0wfBVBc/Mhueb2pIzYh9ZGe79TFZ3B9A+7wR/tPGA3m5tSQyzQJSQ1cVSs5bbQdau656lnI1jbeKDQN3L56bIqPpvlZB/AI1u8AbZSDb9eWxxQ13qYvG9tiEGmc+ZXS0Xv2GhKOOEE/G5+QNY40KPYYm2omYU9KLG/yCgcjKMAMWhz+d1eZ/OPtkSpJUFYAvVSTBkmsjAx/YrrI5evMbborsL7iEdwrfOChLY6IjwpWlYRbs+OOlqph1Y688Nkp+0S/b/YZM63isERjgF2bVse22dpKTEGPaw6JAQDsO28tyZXuUMN54+4PauUyvnVp9b+pqaMhe5b2aBulA6GA5q7lkd6lm9+NFHffIDQ==" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/WebResource31853185.html?d=pXWhQCeIFASIVPlgkOMeu2sYMrMTgaOukhCiER8Nnursodvfw0jQ1WCNZ1OP1ZLx0nywuGopQc1-ZHV_mDscv-XfZpw1&amp;t=636577232940000000" type="text/javascript"></script>


<script src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/WebResource165c165c.html?d=ZyCb6q1afXkb8a5tR9EH3kC7Ce6MzGj7sWKnm5ArWHBi_7ariVkhXg19DMZn45i5Q2575d208gzZdzBwqkfb61VIx4E1&amp;t=636577232940000000" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>
<script type="text/javascript" src="<?php echo e(asset('')); ?>assets/js/core/libraries/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('')); ?>assets/js/core/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('')); ?>assets/js/core/jquery.form.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('')); ?>assets/js/core/sweetalert2.min.js"></script>
<div>

    <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="BF73E0E3" />
    <input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="Fyimb8YHTmrrkVpZozNlrV5P9bRnwwsczIr+gGlOU0PNCQdS0msKgLA33kp0uEIi42WST6C/W8CqPlpDbKwZSgHRn8iEW1c3Rr85t4wPrlnjvWb4dqNf9wqA4mbED65aPOzzPRYba/OpUmcI9FQhwF3SCJWBb/CfW0N7WV0+o1KdLEYMPpGt15XYTcArZph98OzNC7soKHAOsrFQRx14iE30wLFP2jW/GZjm9/5jimtZSaPv" />
</div>
    <input name="txtravi" type="text" value="0" id="txtravi" style="display: none;" />
    
    
    <header class="head_lg">
    <div class=" container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="logo" style="margin:2% 0px 2%;">
                    <?php if($mydata['company']->logo): ?>
                    <a href="#"><img id="imgCompanyLogo" class="img-fluid" src="<?php echo e(asset('public/logos')); ?>/<?php echo e($mydata['company']->logo); ?>" style="border-style:None;border-width:0px;width:150px" /></a>
                    <?php endif; ?>
                    </div>
   

</div>
</div>

</div>

</header>
    <section class="midwrap" style="padding-top: 6%;padding-bottom: 6%;">
    <div class="container-fluid">
        <div class="row ">
          
             <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="easy_secure gry_bx">
                    <div class="center_es">
                        <h4> Our Services </h4>
                        <h2 style=" font-size:10px;">Recharge, Bill Payment, Money Transfer, Aeps, Bbps, Pan, Travel, And ,API Provider company in india </h2>
                        <div class="m_trns_img text-center"><img src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/images/cover-customer-services.svg" class="img-fluid"  alt="img" style="max-height:200px"></div>
                    </div>
                </div>
            </div>
           <div class="col-xl-6 col-lg-12 col-md-12">
               <form  action="<?php echo e(route('authCheck')); ?>" method="POST" class="login-form">
             <?php echo e(csrf_field()); ?>

                <div class="login_f gradient_bg">
                    <div class="row align-items-center">
                        <div id="divLogin" class="col-md-5">
                            <p style="color:red"><b class="errorText"></b></p>
                            <p style="color:teal"><b class="successText"></b></p>
                            <div id="login1">
                                <h4>User Login</h4>
                                <div class="rw">
                                    <p>User ID</p>
                                    <input type="text" class="form-control" placeholder="login id / mobile" name="mobile"  pattern="[0-9]*" maxlength="11" minlength="10" required>
                                    <span id="rfvLoginID" style="color:Red;display:none;"><img src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/images/warning.html"/>

                                    </span>
                                </div>
                                <div class="rw">
                                    <p>Password</p>
                                    <input type="password" class="form-control" placeholder="Password" name="password" placeholder="Password" required>
                                    <a href="javascript:void(0)" id="passwordView" style="position: relative;left: 210px;bottom: 30px;"><i class="fa fa-eye" style="font-size: 20px"></i></a>
                                    
                                    <span id="rfvPassword" style="color:Red;display:none;"><img src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/images/warning.html"/>
                                    </span>
                                </div>
                                <div class="formdata">
                                
                               </div>
                                <div class="rw d-flex align-items-center justify-content-between">
                                     <input type="submit" name="btnLogin" value=" Login "class="btn"  />
                                     <button type="button" data-target="#registerModal" data-toggle="modal" style="width:80px;height:30px;" value="" class="btn">Sign up</button>
                                     
                                     <a  onclick="forgetPassword()" class="link1" href="javascript:void(0)">Forgot Password</a>
                                     <div id="ValidationSummary" style="color:Red;display:none;">

                                    </div>
                                    
                                </div>
                            </div>
                            
                          </div>
                                                    
                        <div class="col-md-7 text-center">
                            <div class="lock">
                                <img src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/images/lock.png" class="img-fluid" alt="img">
                            </div>
                        </div>
                        
                    </div>
                </div>
                </form>
           </div>
             <div class="col-xl-3 col-lg-6 col-md-6">
                <div class="contact_bx gry_bx">
                    <div class="center_es">
                        <h3>Contact Us</h3>
                        <ul>
                            <li><i><img src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/images/company.png" alt="img"></i>  <?php echo e($mydata['address']); ?><br></li>
                            <li><i><img src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/images/address.png" alt="img"></i>  <?php echo e($mydata['city']); ?></li>
                            <li><i><img src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/images/email.png"  alt="img"></i> <?php echo e($mydata['supportemail']); ?></li>
                            <li><i><img src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/images/phone.png"  alt="img"></i><?php echo e($mydata['supportnumber']); ?></li>
                <!--<li><i><img src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/images/whats%20app.png"  alt="img"></i><?php echo e($mydata['supportnumber']); ?></li>                   -->
                            <li><i><img src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/images/web-site.png"  alt="img"></i> <?php echo e($mydata['company']->website); ?> </li>
                        </ul>
                    </div>
                </div>
            </div>
          
        </div>
        
      
    </div>
    <div id="passwordResetModal" class="modal fade" data-backdrop="false" data-keyboard="false">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title pull-left">Password Reset Request</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="passwordRequestForm" action="<?php echo e(route('authReset')); ?>" method="post">
                        <b><p class="text-danger"></p></b>
                        <input type="hidden" name="type" value="request">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label>Mobile</label>
                            <input type="text" name="mobile" class="form-control" placeholder="Enter Mobile Number" required="">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-block text-uppercase waves-effect waves-light" type="submit" data-loading-text="<i class='fa fa-spin fa-spinner'></i> Resetting">Reset Request</button>
                        </div>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

    <div id="passwordModal" class="modal fade" data-backdrop="false" data-keyboard="false">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-slate">
                    <h5 class="modal-title pull-left">Password Reset</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="alert bg-success alert-styled-left no-margin mb-15">
                        <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
                        <span class="text-semibold">Success!</span> Your password reset token successfully sent on your registered e-mail id & Mobile number.
                    </div>
                    <form id="passwordForm" action="<?php echo e(route('authReset')); ?>" method="post">
                        <b><p class="text-danger"></p></b>
                        <input type="hidden" name="mobile">
                        <input type="hidden" name="type" value="reset">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label>Reset Token</label>
                            <input type="text" name="token" class="form-control" placeholder="Enter OTP" required="">
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Enter New Password" required="">
                            
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary btn-block text-uppercase waves-effect waves-light" type="submit" data-loading-text="<i class='fa fa-spin fa-spinner'></i> Resetting">Reset Password</button>
                        </div>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

    <div id="registerModal" class="modal fade right" data-backdrop="false" data-keyboard="false">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-slate">
                    <h5 class="modal-title pull-left">Member Registration</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="registerForm" action="<?php echo e(route('register')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                         <input type="hidden" name="slug" value="retailer" >
                        <legend>Personal Details</legend>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label for="exampleInputEmail1" class="text-uppercase">Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Enter your name" required>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="exampleInputPassword1" class="text-uppercase">Email</label>
                                <input type="text" name="email" class="form-control" placeholder="Enter your email id" required>
                                <div class="alert-message" id="emailError"></div>
                                
                            </div>
                            <div class="form-group col-md-4">
                                <label for="exampleInputPassword1" class="text-uppercase">Mobile</label>
                                <input type="text" name="mobile" class="form-control" placeholder="Enter your mobile" required>
                                <div class="alert-message" id="mobileError"></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label>State</label>
                                <select name="state" class="form-control state" required="">
                                    <option value="">Select State</option>
                                    <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($state->state); ?>"><?php echo e($state->state); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label>City</label>
                                <input type="text" name="city" class="form-control" value="" required="" placeholder="Enter Value">
                            </div>
                            <div class="form-group col-md-4">
                                <label>Pincode</label>
                                <input type="text" name="pincode" class="form-control" value="" required="" maxlength="6" minlength="6" placeholder="Enter Value" pattern="[0-9]*">
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label>Address</label>
                                <textarea name="address" class="form-control" rows="3" required="" placeholder="Enter Value"></textarea>
                            </div>
                        </div>

                        <legend>Kyc Information</legend>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label>Shop Name</label>
                                <input type="text" name="shopname" class="form-control" value="" required="" placeholder="Enter Value">
                                <div class="alert-message" id="shopnameError"></div>
                            </div>
                            <div class="form-group col-md-4">
                                <label>Pancard</label>
                                <input type="text" name="pancard" class="form-control" value="" required="" placeholder="Enter Value">
                                <div class="alert-message" id="pancardError"></div>
                            </div>
                            <div class="form-group col-md-4">
                                <label>Aadhar</label>
                                <input type="text" name="aadharcard" required="" class="form-control" placeholder="Enter Value" pattern="[0-9]*" maxlength="12" minlength="12">
                                <div class="alert-message" id="aadharcardError"></div>
                            </div>
                        </div>
                        <div class="text-center form-group">
                            <button type="submit" class="btn btn-lg bg-slate">Submit</button>
                        </div>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
</section>
    <footer class="footer_lg">
    <div class="container-fluid">
        <div class="footer_center">
            <div class="row">
                <div class="col-md-4 order-md-1 googleplay text-center"><img src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/images/gogle_play.png" class="img-fluid"  alt="img" ></div>
                <div class="col-md-4 order-md-2 follow_us text-right" style="color: #fff;">Follow Us  <a href="https://www.facebook.com/"><i class="fa fa-facebook-f" style="color: #fff;"></i></a>
                <a href="https://twitter.com/"><i class="fa fa-twitter" style="color: #fff;"></i></a>
                <a href="https://www.instagram.com/"><i class="fa fa-instagram" style="color: #fff;"></i></a>
                <a href="https://www.youtube.com/"><i class="fa fa-youtube" style="color: #fff;"></i></a></div>
                <div class="col-md-4 order-md-0">
                                <span id="lblcopy" class="remember">Copyright &copy;  <?php echo e(date('Y')); ?>  <?php echo e($mydata['company']->companyname); ?></span>.
                                 </div>
            </div>
        </div>
    </div>
</footer>
    <script src="<?php echo e(asset('')); ?>assets/nikatby.in/ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.html"></script>
    <script>        window.jQuery || document.write('<script src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/js/libs/jquery-1.7.min.html">\x3C/script>')</script>
    <script src="<?php echo e(asset('')); ?>assets/nikatby.in/login-new/Portal/loginjs/bootstrap.js"></script>
   
    
<script type="text/javascript">
//<![CDATA[
var Page_ValidationSummaries =  new Array(document.getElementById("ValidationSummary"));
var Page_Validators =  new Array(document.getElementById("rfvLoginID"), document.getElementById("rfvPassword"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var rfvLoginID = document.all ? document.all["rfvLoginID"] : document.getElementById("rfvLoginID");
rfvLoginID.controltovalidate = "txtLoginID";
rfvLoginID.focusOnError = "t";
rfvLoginID.errormessage = "Required Field Login Name.";
rfvLoginID.display = "Dynamic";
rfvLoginID.validationGroup = "v";
rfvLoginID.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
rfvLoginID.initialvalue = "";
var rfvPassword = document.all ? document.all["rfvPassword"] : document.getElementById("rfvPassword");
rfvPassword.controltovalidate = "txtPassword";
rfvPassword.focusOnError = "t";
rfvPassword.errormessage = "Required Field Password.";
rfvPassword.display = "Dynamic";
rfvPassword.validationGroup = "v";
rfvPassword.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
rfvPassword.initialvalue = "";
var ValidationSummary = document.all ? document.all["ValidationSummary"] : document.getElementById("ValidationSummary");
ValidationSummary.validationGroup = "v";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        //]]>
</script>
<script>
 $( document ).ready(function() {
            

            $(document).on('click', '#passwordView', function() {
                var passwordType = $(this).closest('form').find('[name="password"]').attr('type');
                if(passwordType == "password"){
                    $(this).closest('form').find('[name="password"]').attr('type', "text");
                    $(this).find('i').removeClass('fa-eye').addClass('fa-eye-slash');
                }else{
                    $(this).closest('form').find('[name="password"]').attr('type', "password");
                    $(this).find('i').addClass('fa-eye').removeClass('fa-eye-slash');
                }
            });
            
            $(document).on('click', '#otpView', function() {
                var passwordType = $(this).closest('form').find('[name="otp"]').attr('type');
                if(passwordType == "password"){
                    $(this).closest('form').find('[name="otp"]').attr('type', "text");
                    $(this).find('i').removeClass('fa-eye').addClass('fa-eye-slash');
                }else{
                    $(this).closest('form').find('[name="otp"]').attr('type', "password");
                    $(this).find('i').addClass('fa-eye').removeClass('fa-eye-slash');
                }
            });

            $( ".login-form" ).validate({
                rules: {
                    mobile: {
                        required: true,
                        minlength: 10,
                        number : true,
                        maxlength: 11
                    },
                    password: {
                        required: true,
                    }
                },
                messages: {
                    mobile: {
                        required: "Please enter mobile number",
                        number: "Mobile number should be numeric",
                        minlength: "Your mobile number must be 10 digit",
                        maxlength: "Your mobile number must be 10 digit"
                    },
                    password: {
                        required: "Please enter password",
                    }
                },
                errorElement: "p",
                errorPlacement: function ( error, element ) {
                    if ( element.prop("tagName").toLowerCase() === "select" ) {
                        error.insertAfter( element.closest( ".form-group" ).find(".select2") );
                    } else {
                        error.insertAfter( element );
                        $
                    }
                },
                submitHandler: function () {
                    var form = $('.login-form');
                    form.ajaxSubmit({
                        dataType:'json',
                        beforeSubmit:function(){
                            swal({
                                title: 'Wait!',
                                text: 'We are checking your login credential',
                                onOpen: () => {
                                    swal.showLoading()
                                },
                                allowOutsideClick: () => !swal.isLoading()
                            });
                        },
                        success:function(data){
                            swal.close();
                            if(data.status == "Login"){
                                swal({
                                    type: 'success',
                                    title : 'Success',
                                    text: 'Successfully logged in.',
                                    showConfirmButton: false,
                                    timer: 2000,
                                    onClose: () => {
                                        window.location.reload();
                                    },
                                });
                            }else if(data.status == "otpsent" || data.status == "preotp"){
                                $('div.formdata').append(`<div class="rw">
                                <p>Otp</p>
                                    <input class="form-control input100" type="password" name="otp" placeholder="Otp" required>
                                    <span class="focus-input100"></span>
                                    <a href="javascript:void(0)" id="otpView" style="position: absolute;right: 25px;bottom: 70px;"><i class="fa fa-eye" style="font-size: 20px"></i></a>
                                </div><a href="javascript:void(0)" onclick="OTPRESEND()" class="text-primary">Resend Otp</a> `);

                                if(data.status == "preotp"){
                                    $('b.successText').text('Please use previous otp sent on your mobile.');
                                    setTimeout(function(){
                                        $('b.successText').text('');
                                    }, 5000);
                                }
                            }
                        },
                        error: function(errors) {
                            swal.close();
                            if(errors.status == '400'){
                                $('b.errorText').text(errors.responseJSON.status);
                                setTimeout(function(){
                                    $('b.errorText').text('');
                                }, 5000);
                            }else{
                                $('b.errorText').text('Something went wrong, try again later.');
                                setTimeout(function(){
                                    $('b.errorText').text('');
                                }, 5000);
                            }
                        }
                    });
                }
            });

            $( "#passwordForm" ).validate({
                rules: {
                    token: {
                        required: true,
                        number : true
                    },
                    password: {
                        required: true,
                    }
                },
                messages: {
                    mobile: {
                        required: "Please enter reset token",
                        number: "Reset token should be numeric",
                    },
                    password: {
                        required: "Please enter password",
                    }
                },
                errorElement: "p",
                errorPlacement: function ( error, element ) {
                    if ( element.prop("tagName").toLowerCase() === "select" ) {
                        error.insertAfter( element.closest( ".form-group" ).find(".select2") );
                    } else {
                        error.insertAfter( element );
                    }
                },
                submitHandler: function () {
                    var form = $('#passwordForm');
                    form.ajaxSubmit({
                        dataType:'json',
                        beforeSubmit:function(){
                            swal({
                                title: 'Wait!',
                                text: 'We are checking your login credential',
                                onOpen: () => {
                                    swal.showLoading()
                                },
                                allowOutsideClick: () => !swal.isLoading()
                            });
                        },
                        success:function(data){
                            if(data.status == "TXN"){
                                $('#passwordModal').modal('hide');
                                swal({
                                    type: 'success',
                                    title: 'Reset!',
                                    text: 'Password Successfully Changed',
                                    showConfirmButton: true
                                });
                            }else{
                                notify(data.message, 'warning');
                            }
                        },
                        error: function(errors) {
                            swal.close();
                            if(errors.status == '400'){
                                notify(errors.responseJSON.status, 'warning');
                            }else{
                                notify('Something went wrong, try again later.', 'warning');
                            }
                        }
                    });
                }
            });

            $( "#registerForm" ).validate({
                rules: {
                    slug: {
                        required: true
                    }
                },
                messages: {
                    slug: {
                        required: "Please select member type",
                    }
                },
                errorElement: "p",
                errorPlacement: function ( error, element ) {
                    if ( element.prop("tagName").toLowerCase() === "select" ) {
                        error.insertAfter( element.closest( ".form-group" ).find(".select2") );
                    } else {
                        error.insertAfter( element );
                    }
                },
                submitHandler: function () {
                    var form = $('#registerForm');
                    form.ajaxSubmit({
                        dataType:'json',
                        beforeSubmit:function(){
                            swal({
                                title: 'Wait!',
                                text: 'We are working on your request',
                                onOpen: () => {
                                    swal.showLoading()
                                },
                                allowOutsideClick: () => !swal.isLoading()
                            });
                        },
                        success:function(data){
                            if(data.status == "TXN"){
                                $('#registerModal').modal('hide');
                                swal({
                                    type: 'success',
                                    title: 'Welcome',
                                    text: 'Your request has been submitted successfully, please wait for confirmation',
                                    showConfirmButton: true
                                });
                            }else{
                                notify(data.message, 'warning');
                            }
                        },
                        error: function(errors) {
                            console.log(errors.responseJSON.errors.mobile);
                            swal.close();
                            if(errors.status == '422'){
                               // notify(errors.responseJSON.errors[0], 'warning');
                               $('#emailError').text(errors.responseJSON.errors.email);
                               $('#mobileError').text(errors.responseJSON.errors.mobile);
                               $('#shopnameError').text(errors.responseJSON.errors.shopname);
                               $('#pancardError').text(errors.responseJSON.errors.pancard);
                               $('#aadharcardError').text(errors.responseJSON.errors.aadharcard);
                              
                            }else{
                                notify('Something went wrong, try again later.', 'warning');
                            }
                        }
                    });
                }
            });
        });
        function notify(msg, type="success"){
            let snackbar  = new SnackBar;
            snackbar.make("message",[
                msg,
                null,
                "bottom",
                "right",
                "text-"+type
            ], 5000);
        }

        function forgetPassword() {
            
            var mobile = $('.login-form').find('[name="mobile"]').val();

            if(mobile != ''){

                $.ajax({
                    url: '<?php echo e(route('authReset')); ?>',
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    dataType:'json',
                    data: {'type': 'request', "mobile": mobile},
                    beforeSend: function () {
                        swal({
                            title: 'Wait!',
                            text: 'We are processing your request',
                            onOpen: () => {
                                swal.showLoading()
                            },
                            allowOutsideClick: () => !swal.isLoading()
                        });
                    }
                }).done(function(data) {
                    swal.close();
                    if(data.status == "TXN"){
                        $('#passwordResetModal').modal('hide');
                        $('#passwordForm').find('input[name="mobile"]').val(mobile);
                        $('#passwordModal').modal('show');
                    }else{
                        $('b.errorText').text(data.message);
                        setTimeout(function(){
                            $('b.errorText').text('');
                        }, 5000);
                    }
                }).fail(function(errors) {
                    swal.close();
                    if(errors.status == '400'){
                        $('b.errorText').text(errors.responseJSON.message);
                        setTimeout(function(){
                            $('b.errorText').text('');
                        }, 5000);
                    }else{
                        $('b.errorText').text("Something went wrong, try again later.");
                        setTimeout(function(){
                            $('b.errorText').text('');
                        }, 5000);
                    }
                });

            }else{
                $('b.errorText').text('Enter your registered mobile number');
                setTimeout(function(){
                    $('b.errorText').text('');
                }, 5000);
            }
        }
        
        function OTPRESEND() {
            var mobile = $('input[name="mobile"]').val();
            var password = $('input[name="password"]').val();
            if(mobile.length > 0){
                $.ajax({
                    url: '<?php echo e(route("authCheck")); ?>',
                    type: 'post',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data :  {'mobile' : mobile, 'password' : password , 'otp' : "resend"},
                    beforeSend:function(){
                        swal({
                            title: 'Wait!',
                            text: 'Please wait, we are working on your request',
                            onOpen: () => {
                                swal.showLoading()
                            }
                        });
                    },
                    complete: function(){
                        swal.close();
                    }
                })
                .done(function(data) {
                    if(data.status == "otpsent"){
                        $('b.successText').text('Otp sent successfully');
                        setTimeout(function(){
                            $('b.successText').text('');
                        }, 5000);
                    }else{
                        $('b.errorText').text(data.message);
                        setTimeout(function(){
                            $('b.errorText').text('');
                        }, 5000);
                    }
                })
                .fail(function() {
                    $('b.errorText').text('Something went wrong, try again');
                    setTimeout(function(){
                        $('b.errorText').text('');
                    }, 5000);
                });
            }else{
                $('b.errorText').text('Enter your registered mobile number');
                setTimeout(function(){
                    $('b.errorText').text('');
                }, 5000);
            }
        }
</script>

</body>
</html>
<?php /**PATH /home/xpresspay/public_html/resources/views/welcome.blade.php ENDPATH**/ ?>